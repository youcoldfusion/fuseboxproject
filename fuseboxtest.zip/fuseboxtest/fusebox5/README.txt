Fusebox 5.5 Core Files

The simplest way to install Fusebox 5.5 is to copy this (fusebox5)
directory to your webroot.

Alternatively, you can create a mapping /fusebox5 that points to
this directory.

Then install the Fusebox 5.5 Skeleton application templates
(see the Downloads section of fusebox.org) and test that
it works.

Fusebox 5.5 supports:
- ColdFusion MX 6.1 and higher
- BlueDragon 7.0 and higher
- Railo 2.0 and higher

See also the Fusebox 5.5 Release Notes in the docs/ directory.
